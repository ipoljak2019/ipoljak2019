package hw;

public class HelloWorld {

  public String getMessage() {
    return "hello world";
  }

  public int getYear() {
    return 2018;
  }
}
